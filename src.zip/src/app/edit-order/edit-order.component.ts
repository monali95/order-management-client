import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { OrderService } from '../order.service';
import { first } from 'rxjs/operators';
import { Router } from '@angular/router';
import { OrderModel } from '../OrderModel';

@Component({
  selector: 'app-edit-order',
  templateUrl: './edit-order.component.html',
  styleUrls: ['./edit-order.component.css']
})
export class EditOrderComponent implements OnInit {

  order: OrderModel;
  editForm: FormGroup;
  submitted = false;
  OrderService: any;
  orderService: any;

  constructor(private formBuilder: FormBuilder, private router: Router, private productService: OrderService) { }

  ngOnInit() {
    const orderId = localStorage.getItem('orderId');
    if (!orderId) {
      alert('Something wrong!');
      this.router.navigate(['']);
      return;
    }

    this.editForm = this.formBuilder.group({
      _id: [],
      name: ['', Validators.required],
      address: ['', Validators.required],
      Phonenumber: ['', Validators.required],
      total: ['', Validators.required]
    });

    this.OrderService.getOrderById(orderId).subscribe(data => {
      console.log(data);
      this.editForm.patchValue(data); // Don't use editForm.setValue() as it will throw console error
    });
  }

  // get the form short name to access the form fields
  get f() { return this.editForm.controls; }

  onSubmit() {
    this.submitted = true;

    if (this.editForm.valid) {
      this.orderService.updateOrder(this.editForm.value)
      .subscribe( data => {
        console.log(data);
        this.router.navigate(['']);
      });
    }
  }

}
