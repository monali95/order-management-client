export class OrderModel {
    _id: string;
    name: String;
    address: String;
    Phonenumber: String;
    total: String;
}
