import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { OrderModel } from '../OrderModel';
import { OrderService } from '../order.service';

@Component({
  selector: 'app-list-orders',
  templateUrl: './list-orders.component.html',
  styleUrls: ['./list-orders.component.css']
})
export class ListOrdersComponent implements OnInit {

  orders: OrderModel[];

  constructor(private orderService: OrderService, private router: Router) { }

  ngOnInit() {
    this.getAllOrders();
  }

  getAllOrders(): void {
    this.orderService.getAllOrders().subscribe(data=>{
      this.orders = data;
    });
  };

  addOrder(): void {
    this.router.navigate(['add-order']);
  }

  deleteOrder(order: OrderModel){
    
    this.orderService.deleteOrder(order._id).subscribe(data=>{
      console.log(data);
      this.getAllOrders();
    });
  }

  updateOrder(order: OrderModel){
    localStorage.removeItem("orderId");
    localStorage.setItem("orderId", order._id);
    this.router.navigate(['edit-order']);
  }

}
