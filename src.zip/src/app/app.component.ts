import { Component } from '@angular/core';

import { SessionService } from './shared/session.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'food ordering';
  constructor(private ss: SessionService) {

  }

  isLoggedIn() {
    //console.log(this.ss.isLoggedIn());
    return this.ss.isLoggedIn();
  }

}
