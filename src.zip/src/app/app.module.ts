import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from "@angular/forms";

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { OrderService } from './order.service';
import { ListOrdersComponent } from './list-orders/list-orders.component';
import { AddOrderComponent } from './add-order/add-order.component';
import { EditOrderComponent } from './edit-order/edit-order.component';
import { UsersModule } from './users/user.module';
import { RouterModule } from '@angular/router';
import { UserService } from './users/user.service';


export const AppRoutes = [

];

@NgModule({
  declarations: [
    AppComponent,
    ListOrdersComponent,
    AddOrderComponent,
    EditOrderComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule, UsersModule,
    RouterModule.forRoot(AppRoutes),
    RouterModule
  ],
  providers: [OrderService,UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
