import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { OrderModel } from './OrderModel';

@Injectable({
  providedIn: 'root'
})
export class OrderService {

  constructor(private http: HttpClient) { }

  baseurl: string = "http://localhost:3000/";

  getAllOrders(){
    return this.http.get<OrderModel[]>(this.baseurl + 'Orders');
  }

  getOrderById(id: string){
    return this.http.get<OrderModel>(this.baseurl + 'Orders' + '/' + id);
  }

  addOrder(order: OrderModel){
    return this.http.post(this.baseurl + 'Orders', order);
  }

  deleteOrder(id: string){
    return this.http.delete(this.baseurl + 'Orders' + '/' + id);
  }

  updateOrder(order: OrderModel){
    return this.http.put(this.baseurl + 'Orders' + '/' + order._id, order);
  }
}
